package net.skhu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class H202114069Application {

	public static void main(String[] args) {
		SpringApplication.run(H202114069Application.class, args);
	}

}
