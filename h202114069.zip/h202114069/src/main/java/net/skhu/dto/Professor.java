package net.skhu.dto;

import lombok.Data;

@Data
public class Professor {
    int id;
    String name;
}

