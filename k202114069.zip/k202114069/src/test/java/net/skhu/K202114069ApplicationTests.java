package net.skhu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K202114069ApplicationTests {

	@Test
	void contextLoads() {
	}

}
